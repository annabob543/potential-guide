export interface UploadApiResult {
  message: string;
  code: number;
  url: string;
}
