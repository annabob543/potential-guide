export { default as SimpleMenu } from './src/SimpleMenu.vue';
