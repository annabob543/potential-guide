import SvgIcon from './src/SvgIcon.vue';
import IconPicker from './src/IconPicker.vue';

export { IconPicker, SvgIcon };
