export enum RoleEnum {
  // super admin
  SUPER = 'super',

  // tester
  TEST = 'test',
}
